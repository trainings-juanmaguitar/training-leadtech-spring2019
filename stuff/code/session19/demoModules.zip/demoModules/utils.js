export const sum = (a,b) => a+b
export const multiply = (a,b) => a*b